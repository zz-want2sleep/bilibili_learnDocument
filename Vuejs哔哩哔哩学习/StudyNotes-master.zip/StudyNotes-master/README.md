# StudyNotes

|              1              |              2              |              3              |              4              |              5              |             6             |
| :--------------------------: | :-----------------------: | :--------------------: | :--: | :---------------------------: | :---------------------------: |
|[Java](./Java)<br>![](https://img.shields.io/badge/%20-007396.svg?style=plastic&logo=java) |[Spring](./Spring/README.md)<br>![](https://img.shields.io/badge/%20-6DB33F.svg?style=plastic&logo=spring) |[Springmvc](./SpringMVC/README.md)<br>![](https://img.shields.io/badge/SpringMVC-6DB33F.svg?style=plastic) |[SpringBoot](./SpringBoot)<br>![](https://img.shields.io/badge/SpringBoot-6DB33F.svg?style=plastic) |[MyBatis](./MyBatis/README.md)<br>![](https://img.shields.io/badge/Mybatis-3776AB.svg?style=plastic) | [Vue](./Vue/README.md)<br>![](https://img.shields.io/badge/%20-FFFFFF.svg?style=plastic&logo=vue.js) |

<br>

|                              1                               |                              2                               |                              3                               |
| :----------------------------------------------------------: | :----------------------------------------------------------: | :----------------------------------------------------------: |
| [MySQL](./MySQL/README.md)<br/>![](https://img.shields.io/badge/%20-FFFFFF.svg?style=plastic&logo=mysql) | [Redis](./Redis/README.md)<br/>![](https://img.shields.io/badge/%20-FFFFFF.svg?style=plastic&logo=redis) | [MongoDB](./MongoDB/README.md)<br/>![](https://img.shields.io/badge/%20-FFFFFF.svg?style=plastic&logo=mongodb) |

<br>

|                              1                               |                              2                               |                              3                               |                              4                               |                              5                               |
| :----------------------------------------------------------: | :----------------------------------------------------------: | :----------------------------------------------------------: | :----------------------------------------------------------: | :----------------------------------------------------------: |
| [Git](./Git/README.md) <br>![](https://img.shields.io/badge/%20-FFFFFF.svg?style=plastic&logo=git) | [Docker](./Docker/README.md)<br>![](https://img.shields.io/badge/%20-FFFFFF.svg?style=plastic&logo=docker) | [Nginx](./Nginx/README.md)<br>![](https://img.shields.io/badge/%20-FFFFFF.svg?style=plastic&logo=nginx) | [前端](./前端)<br>![](https://img.shields.io/badge/Front%20End-3776AB.svg?style=plastic) | [Python](./Python)<br>![](https://img.shields.io/badge/%20-FFFFFF.svg?style=plastic&logo=python) |

