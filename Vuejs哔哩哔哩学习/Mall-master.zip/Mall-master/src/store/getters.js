export default {
  cartLength (state) {
    return state.cartList.length
  },
  cartList () {
    return state.cartList()
  }
}