<template>
  <div class="feature">
    <a href="https://shop.mogu.com/1sr4k?ptp=31.zyjuG.0.0.JO74DYG2">
      <img src="~assets/img/home/recommend_bg.jpg" alt="">
    </a>
  </div>
</template>


<script>
export default {
  name: 'FeatureView'
}
</script>


<style scoped>
  .feature {

  }
  .feature img{
    width: 100%;
    height: 269px;
  }
</style>