<template>
  <div>
    <h1>我的</h1>
  </div>
</template>


<script>
export default {
  name: 'Profile'
}
</script>


<style scoped>

</style>